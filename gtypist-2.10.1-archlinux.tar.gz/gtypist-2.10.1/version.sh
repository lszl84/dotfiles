#! /bin/sh

# Central version definition.

VERSION=2.10.1
echo -n $VERSION
